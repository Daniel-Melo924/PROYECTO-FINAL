/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author hp
 */
public interface Calculo {
    public abstract int admdempr(int ma,int le,int so,int in,int na);
    public abstract int contaduria(int ma,int le,int so,int in,int na);
    public abstract int comercio(int ma,int le,int so,int in,int na);
    public abstract int economia(int ma,int le,int so,int in,int na);
    public abstract int derecho(int ma,int le,int so,int in,int na);
    public abstract int psicologia(int ma,int le,int so,int in,int na);
    public abstract int sociologia(int ma,int le,int so,int in,int na);
    public abstract int ingambiental(int ma,int le,int so,int in,int na);
    public abstract int ingagroind(int ma,int le,int so,int in,int na);
    public abstract int ingsistemas(int ma,int le,int so,int in,int na);
    public abstract int enfermeria(int ma,int le,int so,int in,int na);
    public abstract int instquiru(int ma,int le,int so,int in,int na);
    public abstract int microbiologia(int ma,int le,int so,int in,int na);
    public abstract int licmate(int ma,int le,int so,int in,int na);
    public abstract int licespeing(int ma,int le,int so,int in,int na);
    public abstract int liclitylecas(int ma,int le,int so,int in,int na);
    public abstract int licnatu(int ma,int le,int so,int in,int na);
    public abstract int licrecrydep(int ma,int le,int so,int in,int na);
    public abstract int licarte(int ma,int le,int so,int in,int na);
    public abstract int musica(int ma,int le,int so,int in,int na);
    public abstract int ingelec(int ma,int le,int so,int in,int na);
}
