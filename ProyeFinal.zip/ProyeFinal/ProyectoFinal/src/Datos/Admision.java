/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author hp
 */
public class Admision extends Requisito {
    int snpIcfes;

    public Admision(int snpIcfes, int identificacion, String nombres, String apellidos, int edad) {
        super(identificacion, nombres, apellidos, edad);
        this.snpIcfes = snpIcfes;
    }

    public int getSnpIcfes() {
        return snpIcfes;
    }

    public void setSnpIcfes(int snpIcfes) {
        this.snpIcfes = snpIcfes;
    }
    
    
    
}
