/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author hp
 */
public class Preuniversitario extends Requisito {
    double promedio;

    public Preuniversitario(double promedio, int identificacion, String nombres, String apellidos, int edad) {
        super(identificacion, nombres, apellidos, edad);
        this.promedio = promedio;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
    
    
}
