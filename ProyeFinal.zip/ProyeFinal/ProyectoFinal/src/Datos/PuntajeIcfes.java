/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;



/**
 *
 * @author hp
 */
public class PuntajeIcfes implements Calculo{
    private int matematicas;
    private int lecturacritica;
    private int ingles;
    private int sociales;
    private int naturales;

    public PuntajeIcfes(int matematicas, int lecturacritica, int ingles, int sociales, int naturales) {
        this.matematicas = matematicas;
        this.lecturacritica = lecturacritica;
        this.ingles = ingles;
        this.sociales = sociales;
        this.naturales = naturales;
    }
    
    public int getMatematicas() {
        return matematicas;
    }

    public void setMatematicas(int matematicas) {
        this.matematicas = matematicas;
    }

    public int getLecturacritica() {
        return lecturacritica;
    }

    public void setLecturacritica(int lecturacritica) {
        this.lecturacritica = lecturacritica;
    }

    public int getIngles() {
        return ingles;
    }

    public void setIngles(int ingles) {
        this.ingles = ingles;
    }

    public int getSociales() {
        return sociales;
    }

    public void setSociales(int sociales) {
        this.sociales = sociales;
    }

    public int getNaturales() {
        return naturales;
    }

    public void setNaturales(int naturales) {
        this.naturales = naturales;
    }
    

    @Override
    public int admdempr(int ma, int le, int so, int in, int na) {
         int resultado=(int)((getMatematicas()*0.3)+(getLecturacritica()*0.3)+(getSociales()*0.15)+(getNaturales()*0.1)+(getIngles()*0.15));
         if (resultado>53) {
            return resultado;
        }else{
             resultado=0;
         }
         return resultado;
    }

    @Override
    public int contaduria(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.25)+(getLecturacritica()*0.35)+(getSociales()*0.15)+(getNaturales()*0.1)+(getIngles()*0.15));
        if (resultado>55) {
           return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int comercio(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.15)+(getLecturacritica()*0.30)+(getSociales()*0.15)+(getNaturales()*0.1)+(getIngles()*0.30));
        if (resultado>36) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int economia(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.35)+(getLecturacritica()*0.25)+(getSociales()*0.15)+(getNaturales()*0.1)+(getIngles()*0.15));
        if (resultado>45) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int derecho(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.10)+(getLecturacritica()*0.35)+(getSociales()*0.30)+(getNaturales()*0.1)+(getIngles()*0.15));
        if (resultado>58) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int psicologia(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.10)+(getLecturacritica()*0.35)+(getSociales()*0.30)+(getNaturales()*0.1)+(getIngles()*0.15));
        if (resultado>63) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int sociologia(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.35)+(getLecturacritica()*0.35)+(getSociales()*0.15)+(getNaturales()*0.1)+(getIngles()*0.15));
        if (resultado>55) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int ingambiental(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.25)+(getLecturacritica()*0.20)+(getSociales()*0.15)+(getNaturales()*0.25)+(getIngles()*0.15));
        if (resultado>44) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int ingagroind(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.25)+(getLecturacritica()*0.20)+(getSociales()*0.15)+(getNaturales()*0.25)+(getIngles()*0.15));
        if (resultado>33) {
           return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int ingsistemas(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.30)+(getLecturacritica()*0.20)+(getSociales()*0.15)+(getNaturales()*0.20)+(getIngles()*0.15));
        if (resultado>56) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int enfermeria(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.20)+(getLecturacritica()*0.20)+(getSociales()*0.15)+(getNaturales()*0.25)+(getIngles()*0.20));
        if (resultado>61) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int instquiru(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.20)+(getLecturacritica()*0.10)+(getSociales()*0.15)+(getNaturales()*0.35)+(getIngles()*0.20));
        if (resultado>61) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int microbiologia(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.15)+(getLecturacritica()*0.20)+(getSociales()*0.15)+(getNaturales()*0.30)+(getIngles()*0.20));
        if (resultado>53) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int licmate(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.40)+(getLecturacritica()*0.20)+(getSociales()*0.15)+(getNaturales()*0.10)+(getIngles()*0.15));
        if (resultado>24) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int licespeing(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.10)+(getLecturacritica()*0.40)+(getSociales()*0.15)+(getNaturales()*0.10)+(getIngles()*0.25));
        if (resultado>65) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int liclitylecas(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.10)+(getLecturacritica()*0.40)+(getSociales()*0.15)+(getNaturales()*0.10)+(getIngles()*0.25));
        if (resultado>51) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int licnatu(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.10)+(getLecturacritica()*0.20)+(getSociales()*0.15)+(getNaturales()*0.40)+(getIngles()*0.15));
        if (resultado>52) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int licrecrydep(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.10)+(getLecturacritica()*0.25)+(getSociales()*0.15)+(getNaturales()*0.30)+(getIngles()*0.20));
        if (resultado>50) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int licarte(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.10)+(getLecturacritica()*0.35)+(getSociales()*0.30)+(getNaturales()*0.10)+(getIngles()*0.15));
        if (resultado>44) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int musica(int ma, int le, int so, int in, int na) {
        int resultado=(int)((getMatematicas()*0.30)+(getLecturacritica()*0.30)+(getSociales()*0.15)+(getNaturales()*0.10)+(getIngles()*0.15));
        if (resultado>34) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }

    @Override
    public int ingelec(int ma, int le, int so, int in, int na) {
       int resultado=(int)((getMatematicas()*0.30)+(getLecturacritica()*0.20)+(getSociales()*0.15)+(getNaturales()*0.20)+(getIngles()*0.15));
        if (resultado>35) {
            return resultado;
        }else{
            resultado=0;
        }
        return resultado;
    }
}
