/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import Datos.Admision;

/**
 *
 * @author hp
 */
public class Gestion {
    public static ArrayList<Admision> lista=new ArrayList<Admision>();
    public static String guardar(int snpIcfes, int identificacion, String nombres, String apellidos, int edad){
        String respuesta="Informacion Incorrecta";
        if(snpIcfes>0){
            if(identificacion>0 && nombres!="" && apellidos!="" && edad>0){
                if (lista.size()==0) {
                    lista.add(new Admision(snpIcfes,identificacion,nombres,apellidos,edad));
                    respuesta="Informacion correcta";
                }else{
                    for (int i = 0; i < lista.size(); i++) {
                        if(identificacion==lista.get(i).getIdentificacion()){
                            JOptionPane.showMessageDialog(null,"No se puede matricular 2 veces");
                        }else{
                            lista.add(new Admision(snpIcfes,identificacion,nombres,apellidos,edad));
                            respuesta="Informacion correcta";
                        }
                    }
                }     
            }
        }
        return respuesta;
    }
    
    public static String modificar(int snpIcfes, int identificacion, String nombres, String apellidos, int edad){
        String respuesta="No se puede modificar ";
        for (int i = 0; i < lista.size(); i++) {
            if(snpIcfes>0){
                if(identificacion>0 && nombres!="" && apellidos!="" && edad>0){
                    if(identificacion==lista.get(i).getIdentificacion()){
                        lista.set(i,new Admision(snpIcfes,identificacion,nombres,apellidos,edad));
                        respuesta="Informacion correcta";
                    }
                }
            }
        }
        return respuesta;
    }
    
    public static String Eliminar(int snpIcfes, int identificacion, String nombres, String apellidos, int edad){
        String respuesta="No se puede modificar ";
        for (int i = 0; i < lista.size(); i++) {
            if(snpIcfes>0){
                if(identificacion>0 && nombres!="" && apellidos!="" && edad>0){
                    if(identificacion==lista.get(i).getIdentificacion()){
                        lista.remove(i);
                        respuesta="Informacion correcta";
                    }
                }
            }
        }
        return respuesta="Informacion correcta";
    }
    
}

