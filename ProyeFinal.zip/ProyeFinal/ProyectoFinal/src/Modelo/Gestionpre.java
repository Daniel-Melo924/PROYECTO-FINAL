/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import Datos.Preuniversitario;

/**
 *
 * @author hp
 */
public class Gestionpre {
    public static ArrayList<Preuniversitario> lista=new ArrayList<Preuniversitario>();
    public static String guardar(double promedio, int identificacion, String nombres, String apellidos, int edad){
        String respuesta="Informacion Incorrecta";
        if(promedio>0){
            if(identificacion>0 && nombres!="" && apellidos!="" && edad>0){
                if (lista.size()==0) {
                    lista.add(new Preuniversitario(promedio,identificacion,nombres,apellidos,edad));
                    respuesta="Informacion correcta";
                }else{
                    for (int i = 0; i < lista.size(); i++) {
                        if(identificacion==lista.get(i).getIdentificacion()){
                            JOptionPane.showMessageDialog(null,"No se puede matricular 2 veces");
                        }else{
                            lista.add(new Preuniversitario(promedio,identificacion,nombres,apellidos,edad));
                            respuesta="Informacion correcta";
                        }
                    }
                }     
            }
        }
        return respuesta;
    }
    
    public static String modificar(double promedio, int identificacion, String nombres, String apellidos, int edad){
        String respuesta="No se puede modificar ";
        for (int i = 0; i < lista.size(); i++) {
            if(promedio>0){
                if(identificacion>0 && nombres!="" && apellidos!="" && edad>0){
                    if(identificacion==lista.get(i).getIdentificacion()){
                        lista.set(i,new Preuniversitario(promedio,identificacion,nombres,apellidos,edad));
                        respuesta="Informacion correcta";
                    }
                }
            }
        }
        return respuesta;
    }
    
    public static String Eliminar(double promedio, int identificacion, String nombres, String apellidos, int edad){
        String respuesta="No se puede modificar ";
        for (int i = 0; i < lista.size(); i++) {
            if(promedio>0){
                if(identificacion>0 && nombres!="" && apellidos!="" && edad>0){
                    if(identificacion==lista.get(i).getIdentificacion()){
                        lista.remove(i);
                        respuesta="Informacion correcta";
                    }
                }
            }
        }
        return respuesta="Informacion correcta";
    }
}
