/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import javax.swing.JOptionPane;

/**
 *
 * @author hp
 */
public class Validacion {
    public static int validarEnteros(String numero){
        boolean valido=false;
        int op=0;
        
        try {
            op=Integer.parseInt(numero);
            valido=true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Ingrese un tipo de dato correcto");
        }
        return op;
    }
    
    public static double validarDouble(String numero){
        boolean valido=false;
        double op=0;
        
        try {
            op=Double.parseDouble(numero);
            valido=true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Ingrese un tipo de dato correcto");
        }
        return op;
    }
}
