/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;
import Datos.Admision;

/**
 *
 * @author hp
 */
public class Archivo {
    public static void CrearArchivo(int snpIcfes, int identificacion, String nombres, String apellidos, int edad) throws FileNotFoundException{
        FileOutputStream fos=new FileOutputStream("Editorial.txt",true);
        DataOutputStream dos=new DataOutputStream(fos);
        try {
            Admision nuevo=new Admision(snpIcfes,identificacion,nombres,apellidos,edad);
            snpIcfes=nuevo.getSnpIcfes();
            identificacion=nuevo.getIdentificacion();
            nombres=nuevo.getNombres();
            apellidos=nuevo.getApellidos();
            edad=nuevo.getEdad();
            
            //Escribir datos en el Archivo de texto
            
            dos.writeInt(snpIcfes);
            dos.writeInt(identificacion);
            dos.writeUTF(nombres);
            dos.writeUTF(apellidos);
            dos.writeInt(edad);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }
    }
}
